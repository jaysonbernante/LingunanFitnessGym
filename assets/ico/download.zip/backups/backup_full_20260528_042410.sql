-- Lingunan Fitness Gym — Database Backup
-- Generated: 2026-05-28 04:24:10
-- Filter: ALL records

SET FOREIGN_KEY_CHECKS=0;

-- Table: members
DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `membership_start` date DEFAULT NULL,
  `membership_end` date DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gmail` varchar(100) NOT NULL,
  `RFID` varchar(50) DEFAULT NULL,
  `Joined_Date` date DEFAULT curdate(),
  `credit` decimal(10,2) DEFAULT 0.00,
  `plan_months` int(11) DEFAULT NULL,
  `membership_expiry` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `members_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `members` (`id`, `user_id`, `first_name`, `last_name`, `phone`, `address`, `type`, `membership_start`, `membership_end`, `password`, `username`, `gmail`, `RFID`, `Joined_Date`, `credit`, `plan_months`, `membership_expiry`) VALUES
('5', NULL, 'asd', '', '', '', 'member', NULL, NULL, '$2y$10$upP3tN6xk9lmZXpcLTalbuBVSX4qcbF.La74LudLcegUGd8as.5Qa', 'asd', 'asd@example.com', '111', '2026-04-13', '0.00', NULL, NULL),
('6', NULL, 'jayson', 'bernante', '', '', 'session', NULL, NULL, '$2y$10$MNXZPTcntSM6U8Go8ebXXO/Rsum1Rdehwuy0tSdxiAby04aG/M6/m', 'jaysonbernante', '', '11', '2026-04-13', '440.00', NULL, NULL),
('18', NULL, 'ben', 'onde', '098564645', 'caloocan', 'session', NULL, NULL, '$2y$10$n7Vj0WpCibfHTaXsDK4gHOnRvQPyG9MCUwYsjhSXy5LhzT/IGmh/y', 'benonde', 'benonde@gmail.com', NULL, '2026-04-15', '0.00', NULL, NULL),
('19', NULL, 'alegria', 'hosting', '123123123123', 'asdasdd', 'member', NULL, NULL, '$2y$10$UpyVMci82F8J44PeQPJVYeFlwO7ZskQGGd4D3BacUJHp14tDZHpRW', 'alegriahosting', 'alegriasystemmngr@gmail.com', '1244219170', '2026-04-17', '1222.00', '1', '2026-05-17'),
('21', NULL, 'jerome', 'bernante', '', '', 'session', NULL, NULL, '$2y$10$bBZ27KQTtOkqGCEBmeSvL.d4PLWAYb32sN0oNyhdFQOadMMSYs5rS', 'jeromebernante', '', '1261553234', '2026-04-17', '0.00', NULL, NULL);

-- Table: entry_logs
DROP TABLE IF EXISTS `entry_logs`;
CREATE TABLE `entry_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_name` varchar(100) NOT NULL DEFAULT 'Walk-in',
  `entry_type` varchar(20) NOT NULL DEFAULT 'session',
  `amount_charged` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(20) NOT NULL DEFAULT 'cash',
  `entry_time` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `entry_logs` (`id`, `member_id`, `member_name`, `entry_type`, `amount_charged`, `payment_method`, `entry_time`) VALUES
('1', '5', 'asd', 'membership', '0.00', 'free', '2026-04-14 03:11:26'),
('2', NULL, 'asd', 'walk-in', '50.00', 'cash', '2026-04-14 03:11:58'),
('3', '6', 'jayson bernante', 'session', '50.00', 'credit', '2026-04-15 22:16:14'),
('4', '5', 'asd', 'membership', '0.00', 'free', '2026-04-15 22:24:22'),
('5', NULL, 'yordan', 'walk-in', '50.00', 'cash', '2026-04-15 22:25:11'),
('6', '19', 'alegria hosting', 'membership', '0.00', 'free', '2026-04-17 17:59:15'),
('7', '19', 'alegria hosting', 'membership', '0.00', 'free', '2026-04-17 17:59:18'),
('8', '19', 'alegria hosting', 'membership', '0.00', 'free', '2026-04-17 17:59:19'),
('9', '19', 'alegria hosting', 'membership', '0.00', 'free', '2026-04-17 17:59:26'),
('10', '19', 'alegria hosting', 'membership', '0.00', 'free', '2026-04-17 17:59:34'),
('11', '20', 'jerome bernante', 'membership', '0.00', 'free', '2026-04-17 19:49:24'),
('12', '20', 'jerome bernante', 'membership', '0.00', 'free', '2026-04-17 19:49:33'),
('13', '21', 'jerome bernante', 'session', '50.00', 'cash', '2026-04-17 19:50:25'),
('14', '21', 'jerome bernante', 'session', '50.00', 'cash', '2026-04-17 19:51:42'),
('15', NULL, 'yordan', 'walk-in', '50.00', 'cash', '2026-05-27 10:40:03');

-- Table: sales
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `qty_sold` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `sold_at` datetime DEFAULT current_timestamp(),
  `payment_method` varchar(20) DEFAULT 'cash',
  `member_name` varchar(100) DEFAULT NULL,
  `transacted_by` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sales` (`id`, `product_id`, `product_name`, `qty_sold`, `unit_price`, `total`, `sold_at`, `payment_method`, `member_name`, `transacted_by`, `transaction_id`) VALUES
('26', '6', 'shabu', '5', '100.00', '500.00', '2026-04-15 22:20:59', 'cash', '-', 'admin', 'f7af2b85cab86017'),
('27', '6', 'shabu', '5', '100.00', '500.00', '2026-04-15 22:22:51', 'card', 'jayson bernante', 'admin', 'd9052a090e0a302e'),
('28', '6', 'shabu', '2', '100.00', '200.00', '2026-04-15 22:23:31', 'card', 'jayson bernante', 'admin', 'b0aeef5a5cd1d853'),
('29', '7', 'shake', '2', '10.00', '20.00', '2026-04-15 22:23:31', 'card', 'jayson bernante', 'admin', 'b0aeef5a5cd1d853'),
('30', '6', 'shabu', '3', '100.00', '300.00', '2026-04-17 18:17:12', 'cash', '-', 'admin', '9dd1ff9263481e56'),
('31', '6', 'shabu', '3', '100.00', '300.00', '2026-04-17 18:17:53', 'cash', '-', 'admin', '998f0871406432d8'),
('32', '7', 'shake', '4', '10.00', '40.00', '2026-04-17 18:17:53', 'cash', '-', 'admin', '998f0871406432d8'),
('33', '7', 'shake', '3', '10.00', '30.00', '2026-04-17 18:23:23', 'cash', '-', 'admin', '60c1ca0514e66802'),
('34', '8', 'Boiled Egg', '1', '15.00', '15.00', '2026-05-27 10:39:32', 'cash', '-', 'admin', 'e82cc0cebd9b5960'),
('35', '8', 'Boiled Egg', '1', '15.00', '15.00', '2026-05-27 11:53:11', 'cash', '-', 'admin', '152fcfbed71f7cd4');

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('super_admin','staff') DEFAULT 'staff',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(10) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`, `status`) VALUES
('1', 'admin', '$2y$10$PEsXIWlBFf3dqwJnx8Z4..ucCQKz0K8JxsQpwG6CxQKbb4trcnvn6', 'admin@example.com', 'super_admin', '2026-04-12 01:43:31', 'active'),
('3', 'asd', '$2y$10$470XpC7qnO/sFKFU9Pmh1eK53s3NXeL1lJpjDhRHBIZijl8VCggda', 'asd@example.com', 'staff', '2026-04-13 04:46:38', 'active');

-- Table: products
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `date_stocked` date DEFAULT curdate(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`id`, `product_name`, `quantity`, `price`, `img`, `date_stocked`) VALUES
('7', 'shake', '19', '10.00', '', '2026-04-15'),
('8', 'Boiled Egg', '48', '15.00', '', '2026-04-20');

-- Table: blocked_rfids
DROP TABLE IF EXISTS `blocked_rfids`;
CREATE TABLE `blocked_rfids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rfid` varchar(100) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `blocked_at` datetime DEFAULT current_timestamp(),
  `reason` varchar(100) DEFAULT 'lost',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- (no rows match filter for blocked_rfids)

SET FOREIGN_KEY_CHECKS=1;
